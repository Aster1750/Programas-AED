namespace VSCode
{
    public class Livro
    {
        public string Titulo;

        public int numeroPag;

        public double precoLivro;
    }
}