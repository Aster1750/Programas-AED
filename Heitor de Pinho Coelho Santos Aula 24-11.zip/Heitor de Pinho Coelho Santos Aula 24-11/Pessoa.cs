namespace VSCode
{
    public class Pessoa
    {
        public string Nome;
        public int Ano;
        public string Endereco;
        public int telefone;
        public int Mes;
    }
}